import onnxruntime as ort
import numpy as np
import joblib

# Load scaler
scaler = joblib.load("model/scaler.pkl")

# Load ONNX model
session = ort.InferenceSession("model/fake_banking_detector.onnx")

# Sample app features (same order as dataset)
sample_app = np.array([[
    30, 8, 1, 1, 0, 1, 900, 10, 24, 6
]], dtype=np.float32)

# Scale input ✅
sample_app_scaled = scaler.transform(sample_app)

# Run inference
input_name = session.get_inputs()[0].name
prediction = session.run(None, {input_name: sample_app_scaled})

pred_label = prediction[0][0]

if pred_label == 1:
    print("⚠️ FAKE / SUSPICIOUS banking app")
else:
    print("✅ LEGITIMATE banking app")
