# export_onnx.py
# Converts trained sklearn model to ONNX format

from skl2onnx import convert_sklearn
from skl2onnx.common.data_types import FloatTensorType

def export_model_to_onnx(model, feature_count, output_path):
    """
    Converts a trained sklearn model to ONNX format.
    """

    initial_type = [('float_input', FloatTensorType([None, feature_count]))]
    onnx_model = convert_sklearn(model, initial_types=initial_type)

    with open(output_path, "wb") as f:
        f.write(onnx_model.SerializeToString())

    print("ONNX model exported successfully to:", output_path)
