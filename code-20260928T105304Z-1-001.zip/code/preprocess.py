# preprocess.py
# Handles data loading and preprocessing

import pandas as pd
from sklearn.preprocessing import StandardScaler

def load_and_preprocess(dataset_path, sample_rows=200_000):
    """
    Loads dataset and applies preprocessing.
    Sampling is used because dataset is ~1GB.
    """

    # Load sampled data
    df = pd.read_csv(dataset_path, nrows=sample_rows)

    # Separate features and label
    X = df.drop("label", axis=1)
    y = df["label"]

    # Scale features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    return X_scaled, y
